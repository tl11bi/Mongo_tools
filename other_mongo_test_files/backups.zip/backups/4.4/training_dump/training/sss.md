S D:\mongodb\mongomirror-0.12.7\bin> ./mongomirror.exe --help
Usage:
  mongomirror --host <replicaSetName/hosts> --destination <target>
Copy data continuously from the source over to the destination.

general options:
      /help                                                  print usage
      /version                                               print the tool
                                                             version and exit
      /config:                                               path to a
                                                             configuration file

verbosity options:
  /v, /verbose:<level>                                       more detailed log
                                                             output (include
                                                             multiple times for
                                                             more verbosity,
                                                             e.g. -vvvvv, or
                                                             specify a numeric
                                                             value, e.g.
                                                             --verbose=N)
      /quiet                                                 hide all log output

connection options:
  /h, /host:<hostname>                                       mongodb host to
                                                             connect to
                                                             (setname/host1,hos-

                                                             t2 for replica
                                                             sets)
      /port:<port>                                           server port (can
                                                             also use --host
                                                             hostname:port)
      /compressors:<snappy,...>                              comma-separated
                                                             list of
                                                             compressors to
                                                             enable. Use 'none'
                                                             to disable.
                                                             (default:
                                                             snappy,zstd,zlib)

ssl options:
      /ssl                                                   connect to a
                                                             mongod or mongos
                                                             that has ssl
                                                             enabled
      /sslCAFile:<filename>                                  the .pem file
                                                             containing the
                                                             root certificate
                                                             chain from the
                                                             certificate
                                                             authority
      /sslPEMKeyFile:<filename>                              the .pem file
                                                             containing the
                                                             certificate and key
      /sslPEMKeyPassword:<password>                          the password to
                                                             decrypt the
                                                             sslPEMKeyFile, if
                                                             necessary
      /sslCRLFile:<filename>                                 the .pem file
                                                             containing the
                                                             certificate
                                                             revocation list
      /sslFIPSMode                                           use FIPS mode of
                                                             the installed
                                                             openssl library
      /tlsInsecure                                           bypass the
                                                             validation for
                                                             server's
                                                             certificate chain
                                                             and host name

authentication options:
  /u, /username:<username>                                   username for
                                                             authentication
  /p, /password:<password>                                   password for
                                                             authentication
      /authenticationDatabase:<database-name>                database that
                                                             holds the user's
                                                             credentials
      /authenticationMechanism:<mechanism>                   authentication
                                                             mechanism to use
      /awsSessionToken:<aws-session-token>                   session token to
                                                             authenticate via
                                                             AWS IAM

kerberos options:
      /gssapiServiceName:<service-name>                      service name to
                                                             use when
                                                             authenticating
                                                             using
                                                             GSSAPI/Kerberos
                                                             (default: mongodb)
      /gssapiHostName:<host-name>                            hostname to use
                                                             when
                                                             authenticating
                                                             using
                                                             GSSAPI/Kerberos
                                                             (default: <remote
                                                             server's address>)

destination authentication options:
      /destinationUsername:<username>                        username for
                                                             authentication
      /destinationPassword:<password>                        password for
                                                             authentication
      /destinationAuthenticationDatabase:<database-name>     database that
                                                             holds the user's
                                                             credentials
      /destinationAuthenticationMechanism:<mechanism>        authentication
                                                             mechanism to use

mongomirror options:
      /destination:<setname/hosts>                           specify the host
                                                             or hosts in Atlas
                                                             to which data
                                                             should be
                                                             imported. Format:
                                                             [setname/]host[,ho-

                                                             st2,...]
  /j, /numParallelCollections:<number>                       number of
                                                             collections to
                                                             dump and restore
                                                             in parallel
                                                             (default: 4)
      /bookmarkFile:<mongomirror.bookmark>                   location of the
                                                             oplog bookmark
                                                             file (called
                                                             'mongomirror.bookm-

                                                             ark' by default)
                                                             (default:
                                                             mongomirror.bookma-

                                                             rk)
      /forceDump                                             force re-dumping
                                                             all source
                                                             collections, even
                                                             if there is a
                                                             nonempty bookmark
                                                             file present
      /readPreference:                                       REMOVED - this
                                                             option will error
                                                             if changed from
                                                             the default
                                                             (default: primary)
      /httpStatusPort:<port>                                 port on which to
                                                             enable HTTP status
                                                             server (on
                                                             localhost).
                                                             Without this
                                                             option, no status
                                                             server is started.
      /pprof:<port>                                          port on which to
                                                             enable HTTP pprof
                                                             server (on
                                                             localhost).
                                                             Without this
                                                             option, no pprof
                                                             server is started.
      /drop                                                  drop all
                                                             non-system
                                                             collections before
                                                             mirroring
      /replicateConfigDB                                     enable replication
                                                             of the "config"
                                                             database
      /preserveUUIDs                                         preserve
                                                             collection UUIDs
                                                             when replicating
                                                             from MongoDB >=3.6
      /oplogBatchSize:<number>                               maximum number of
                                                             ops to send as a
                                                             batch (default:
                                                             10000)
      /oplogPath:<directory-path>                            directory to store
                                                             oplog entries from
                                                             the source during
                                                             initial sync, if
                                                             not given
                                                             mongomirror will
                                                             not write the
                                                             oplog to disk
      /includeNamespace:<database.collection>                namespace to
                                                             mirror (defaults
                                                             to all). May be
                                                             provided multiple
                                                             times, and used
                                                             with
                                                             --includeDatabase.
      /includeDB:<database>                                  database to mirror
                                                             (defaults to all).
                                                             May be provided
                                                             multiple times,
                                                             and used with with
                                                             --includeNamespace.
      /collStatsThreshold:<number>                           when number of
                                                             collections
                                                             exceeds this
                                                             value, collStats
                                                             is disabled. Use
                                                             -1 to always run
                                                             collStats or 0 to
                                                             never run
                                                             collStats.
                                                             (default: -1)
      /fixDottedHashIndex                                    when enabled, all
                                                             the hashed index
                                                             on dotted field
                                                             will be created as
                                                             single field index
                                                             on the destination
      /destServerSelectionTimeout:<seconds>                  number of seconds
                                                             to wait for server
                                                             selection on the
                                                             destination; 0
                                                             means driver
                                                             default (default:
                                                             120)
      /noIndexRestore                                        when enabled,
                                                             mongomirror will
                                                             not copy over
                                                             indexes
      /removeAutoIndexId                                     when enabled,
                                                             mongomirror will
                                                             not copy the
                                                             autoIndexId option
                                                             on collections
PS D:\mongodb\mongomirror-0.12.7\bin> 